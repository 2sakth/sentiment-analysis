# Twitter-Sentiment-Classifier
 We classify the Zomato Case tweets and use a DeepLearning model to classify realtime tweets
 
![Main page](https://raw.githubusercontent.com/bhargavyagnik/Realtime-Twitter-Sentiment/main/screenshots/main.jpg)
![text](https://raw.githubusercontent.com/bhargavyagnik/Realtime-Twitter-Sentiment/main/screenshots/text.jpg)
![List of tweets](https://raw.githubusercontent.com/bhargavyagnik/Realtime-Twitter-Sentiment/main/screenshots/list_tweets.jpg)